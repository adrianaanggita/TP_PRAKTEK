
public enum JenisKelamin {
	PRIA,
	WANITA
	
	//generic programming
	//1. Enumeration
	//2. Generic class
	//3. Generic method
}
